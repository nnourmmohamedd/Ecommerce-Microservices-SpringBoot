package com.example.wallet_service.controller;

import com.example.wallet_service.*;
import com.example.wallet_service.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/wallet")
public class WalletController {

    @Autowired
    private WalletService walletService;

    // Register: supports both POST (Postman) and GET (browser test)
    @RequestMapping(value = "/register", method = {RequestMethod.POST, RequestMethod.GET})
    public AppUser register(@RequestBody(required = false) Map<String, String> body) {
        String username = (body != null) ? body.get("username") : "defaultUser";
        String password = (body != null) ? body.get("password") : "defaultPass";
        return walletService.registerUser(username, password);
    }

    // Optional test endpoint for browser
    @GetMapping("/test-register")
    public AppUser testRegister() {
        return walletService.registerUser("browserUser", "test123");
    }
    @Autowired
    private WalletRepository walletRepository;

    @GetMapping("/{id}")
    public ResponseEntity<Wallet> getWallet(@PathVariable Long id) {
        Optional<Wallet> wallet = walletRepository.findById(id);
        return wallet.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }


    // Deposit
    @PostMapping("/{userId}/deposit")
    public WalletDTO deposit(@PathVariable Long userId, @RequestParam BigDecimal amount) {
        Wallet wallet = walletService.deposit(userId, amount);
        return new WalletDTO(wallet.getId(), wallet.getBalance());
    }

    // Withdraw
    @PostMapping("/{userId}/withdraw")
    public WalletDTO withdraw(@PathVariable Long userId, @RequestParam BigDecimal amount) {
        Wallet wallet = walletService.withdraw(userId, amount);
        return new WalletDTO(wallet.getId(), wallet.getBalance());
    }

    // Transaction History
    @GetMapping("/{userId}/transactions")
    public List<Transaction> history(@PathVariable Long userId) {
        return walletService.getTransactionHistory(userId);
    }

    // Handle "Insufficient balance" gracefully
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, String> handleIllegalArgument(IllegalArgumentException ex) {
        return Map.of("error", ex.getMessage());
    }
}
