package com.example.wallet_service.service;

import com.example.wallet_service.*;
import com.example.wallet_service.AppUser;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class WalletService {

    @Autowired
    private AppUserRepository userRepository;

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    // Register user + create wallet
    public AppUser registerUser(String username, String password) {
        AppUser user = new AppUser();
        user.setUsername(username);
        user.setPassword(password); // NOTE: Hash the password in production!

        Wallet wallet = new Wallet();
        wallet.setBalance(BigDecimal.ZERO);
        wallet.setUser(user);
        user.setWallet(wallet);

        return userRepository.save(user);
    }

    // Deposit money
    public Wallet deposit(Long userId, BigDecimal amount) {
        AppUser user = userRepository.findById(userId).orElseThrow();
        Wallet wallet = user.getWallet();

        wallet.setBalance(wallet.getBalance().add(amount));
        walletRepository.save(wallet);

        Transaction tx = new Transaction();
        tx.setWallet(wallet);
        tx.setAmount(amount);
        tx.setType("DEPOSIT");
        tx.setTimestamp(LocalDateTime.now());
        transactionRepository.save(tx);

        return wallet;
    }

    // Withdraw money
    public Wallet withdraw(Long userId, BigDecimal amount) {
        AppUser user = userRepository.findById(userId).orElseThrow();
        Wallet wallet = user.getWallet();

        if (wallet.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException("Insufficient balance");

        }

        wallet.setBalance(wallet.getBalance().subtract(amount));
        walletRepository.save(wallet);

        Transaction tx = new Transaction();
        tx.setWallet(wallet);
        tx.setAmount(amount);
        tx.setType("WITHDRAWAL");
        tx.setTimestamp(LocalDateTime.now());
        transactionRepository.save(tx);

        return wallet;
    }

    // Get transaction history
    public List<Transaction> getTransactionHistory(Long userId) {
        AppUser user = userRepository.findById(userId).orElseThrow();
        return user.getWallet().getTransactions();
    }
}