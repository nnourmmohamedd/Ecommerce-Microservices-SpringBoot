package com.example.inventory_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryService {

    @Autowired
    private InventoryItemRepository repository;

    public InventoryItem addItem(String name, int quantity, double price) {
        InventoryItem item = new InventoryItem();
        item.setProductName(name);
        item.setQuantity(quantity);
        return repository.save(item);
    }

    public InventoryItem getItemById(Long id)
    { //throw new RuntimeException("Simulated failure");
        return repository.findById(id).orElse(null);
    }


    public List<InventoryItem> getAllItems() {
        return repository.findAll();
    }

    public InventoryItem updateQuantity(Long id, int newQty) {
        InventoryItem item = repository.findById(id).orElseThrow(() -> new RuntimeException("Item not found"));
        item.setQuantity(newQty);
        return repository.save(item);
    }
}
