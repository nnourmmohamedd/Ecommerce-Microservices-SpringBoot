package com.example.inventory_service;

import com.example.inventory_service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    @PostMapping("/add")
    public InventoryItem addItem(@RequestBody InventoryItem item) {
        return inventoryService.addItem(item.getProductName(), item.getQuantity(), item.getPrice());
    }

    @GetMapping("/all")
    public List<InventoryItem> getAllItems() {
        return inventoryService.getAllItems();
    }

    @GetMapping("/{id}")
    public ResponseEntity<InventoryItem> getItemById(@PathVariable Long id) {
        InventoryItem item = inventoryService.getItemById(id);
        if (item == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(item);
    }


    @PutMapping("/{id}/update")
    public InventoryItem updateQuantity(@PathVariable Long id, @RequestParam int quantity) {
        return inventoryService.updateQuantity(id, quantity);
    }
}
