package com.example.shop_service;

import com.example.shop_service.client.InventoryClient;
import com.example.shop_service.client.WalletClient;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShopService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private InventoryClient inventoryClient;

    @Autowired
    private WalletClient walletClient;

    // 🛒 Add a product to DB
    public Product addProduct(String name, int price) {
        Product product = new Product();
        product.setName(name);
        product.setPrice(price);
        return productRepository.save(product);
    }

    // 📦 Get all products
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // 🧾 Purchase logic with circuit breakers on both inventory & wallet
    @CircuitBreaker(name = "inventoryService", fallbackMethod = "inventoryFallback")
    public String purchase(PurchaseRequest request) {
        if (request.getItemId() == null || request.getUserId() == null || request.getQuantity() <= 0) {
            return "Invalid request: itemId, userId, and quantity must be provided.";
        }

        InventoryItem item = inventoryClient.getItem(request.getItemId());

        if (item == null) {
            return "Item not found.";
        }

        if (item.getQuantity() < request.getQuantity()) {
            return "Insufficient stock.";
        }

        double total = item.getPrice() * request.getQuantity();

        return withdrawAndUpdate(request, item, total);
    }



    @CircuitBreaker(name = "walletService", fallbackMethod = "walletFallback")
    public String withdrawAndUpdate(PurchaseRequest request, InventoryItem item, double total) {
        walletClient.withdraw(request.getUserId(), total);
        inventoryClient.updateQuantity(item.getId(), item.getQuantity() - request.getQuantity());
        return "Purchase successful!";
    }

    // Fallback for Inventory failure
    public String inventoryFallback(PurchaseRequest request, Throwable t) {
        return "Purchase failed (Inventory Service Unavailable): " + t.getMessage();
    }

    // Fallback for Wallet failure
    public String walletFallback(PurchaseRequest request, InventoryItem item, double total, Throwable t) {
        return "Purchase failed (Wallet Service Unavailable): " + t.getMessage();
    }
}
