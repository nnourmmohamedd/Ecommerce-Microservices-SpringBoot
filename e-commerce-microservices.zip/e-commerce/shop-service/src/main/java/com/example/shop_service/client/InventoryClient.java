package com.example.shop_service.client;

import com.example.shop_service.InventoryItem;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "inventory-service")
public interface InventoryClient {
    @GetMapping("/api/inventory/{id}")
    InventoryItem getItem(@PathVariable("id") Long id);

    @PutMapping("/api/inventory/{id}/update")
    void updateQuantity(@PathVariable("id") Long id, @RequestParam("quantity") int quantity);
}

