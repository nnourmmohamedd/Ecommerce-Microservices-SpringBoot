package com.example.shop_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shop")
public class ShopController {

    @Autowired
    private ShopService shopService;

    // Add a new product
    @PostMapping("/add")
    public Product addProduct(@RequestBody Product product) {
        return shopService.addProduct(product.getName(), product.getPrice());
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return shopService.getAllProducts();
    }


    // Purchase a product
    @PostMapping("/purchase")
    public String purchase(@RequestBody PurchaseRequest request) {
        return shopService.purchase(request);
    }
}
