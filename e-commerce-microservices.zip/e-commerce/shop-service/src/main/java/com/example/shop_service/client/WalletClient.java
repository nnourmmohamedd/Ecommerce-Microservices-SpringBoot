package com.example.shop_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "wallet-service")
public interface WalletClient {

    @PostMapping("/api/wallet/{userId}/withdraw")
    void withdraw(@PathVariable("userId") Long userId, @RequestParam double amount);
}